import '../../styles/footer.css'

const Footer = (props) => {
    return (
        <footer>
            <p>Designed by: Gemdelle - 2022</p>
        </footer>
    )
}

export default Footer;